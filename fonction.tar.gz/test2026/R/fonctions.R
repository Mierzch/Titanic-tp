#' Teste si un nombre est pair
#'
#' Renvoie TRUE si n est pair, FALSE sinon.
#'
#' @author Sylvain Mierzchala
#'
#' @param n Entier a tester
#' @return TRUE si n est pair, FALSE sinon
#' @export
#'
#' @examples
#' pair_SM(3)
#' pair_SM(2)
pair_SM <- function(n) {
  return(n %% 2 == 0)
}


#' Trace un cercle de rayon donne
#'
#' Dessine un cercle centre en (0, 0).
#'
#' @author Sylvain Mierzchala
#'
#' @param R Rayon du cercle
#' @return Un graphique du cercle
#' @export
#'
#' @examples
#' cercle_SM(1)
#' cercle_SM(2)
cercle_SM <- function(R) {
  theta <- seq(0, 2 * pi, length.out = 200)
  x <- R * cos(theta)
  y <- R * sin(theta)
  plot(x, y, type = "l", asp = 1, col = "blue", lwd = 2,
       main = paste("Cercle de rayon", R))
}


#' Taux de survie selon une variable
#'
#' Calcule le taux de survie (en %) pour chaque modalite d'une variable
#' du jeu de donnees TitanicSurvival.
#'
#' @author Sylvain Mierzchala
#'
#' @param data Un data frame contenant une colonne survived ("no"/"yes")
#' @param variable Nom de la variable de regroupement (ex : "sex")
#' @return Un vecteur nomme des taux de survie en %
#' @export
#'
#' @examples
#' library(carData)
#' taux_survie(TitanicSurvival, "sex")
#' taux_survie(TitanicSurvival, "passengerClass")
taux_survie <- function(data, variable) {
  tab <- prop.table(table(data[[variable]], data$survived), margin = 1)
  round(tab[, "yes"] * 100, 1)
}
